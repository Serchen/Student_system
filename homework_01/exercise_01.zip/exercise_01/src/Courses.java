import java.util.Scanner;
import java.util.Vector;

public class Courses {
    static Vector<Course>clist = new Vector();
    public static void addCourse(){
        if(clist.size() < 1)
            clist.add(Course.inputCourse(1));
        else{
            clist.add(Course.inputCourse(clist.size()+1));
        }
    }
    public static void addCourses(){
        int i = 1;
        Scanner sc = new Scanner(System.in);
        while(true){
            System.out.println("请输入第"+(i++)+"次添加的课程的信息");
            addCourse();
            System.out.println("想继续输入，请输入y，否则输入n");
            if(sc.next().equals("y"))
                continue;
            else
                break;
        }
    }
    public static void SortCourseList(){
        for(int i=0; i<clist.size(); i++)
        {
            for(int j=i+1; j<clist.size(); j++)
            {
                Course k = clist.get(j);
                Course c = clist.get(i);
                Course m = c;
                if(c.stuNum < k.stuNum){
                    clist.set(i, k);
                    clist.set(j, m);
                }
            }
        }
    }
    public static void SearchCourseByTeacher(){
        System.out.println("请输入要查找的老师名称");
        Scanner in = new Scanner(System.in);
        String teacher_name = in.next();
        for(int i=0; i<clist.size(); i++)
        {
            Course tmp = clist.get(i);
            if(tmp.teacher.equals(teacher_name)){
            tmp.show();
        }
        }
    }

    public static void DeleteCourse(){
        System.out.println("请输入想要删除的课程名称");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        for(int i=0; i<clist.size(); i++)
        {
            if(clist.get(i).name.equals(name)){
                clist.remove(i);
                break;
            }
        }
    }

//    public static void main(String[] args) {
//        Courses.addCourses();
//        Courses.SortCourseList();
//        Courses.SearchCourseByTeacher();
//    }
}
