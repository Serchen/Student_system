import java.util.Scanner;
import java.util.Vector;

public class Users {
    User administrator = new User("admin", "296559");
    static Vector<Student> studentList = new Vector<Student>();
    static Vector<Teacher> teacherList = new Vector<Teacher>();

    public Users(){

    }
    public void login(){
        System.out.println("请输入您的身份，1代表管理员，2代表学生，3代表教师");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        String pass;
        int id;
        switch (choice){
            case 1:
                System.out.println("请输入管理员密码");
                pass = sc.next();
                if(administrator.getPassword().equals(pass))
                    System.out.println("登录成功");
                else
                    System.out.println("密码不正确，登录失败");
                break;
            case 2:
                System.out.println("请输入您的学号：");
                id = sc.nextInt();
                System.out.println("请输入您的密码：");
                pass = sc.next();
                for(int i=0; i<studentList.size(); i++){
                    if (studentList.get(i).stu_id == id) {
                        if(studentList.get(i).getPassword().equals(pass))
                            System.out.println("登录成功");
                        else
                            System.out.println("密码不正确，登录失败");
                        break;
                    }
                }
                break;
            case 3:
                System.out.println("请输入您的工号：");
                id = sc.nextInt();
                System.out.println("请输入您的密码：");
                pass = sc.next();
                for(int i=0; i<teacherList.size(); i++){
                    if (teacherList.get(i).work_id == id) {
                        if(teacherList.get(i).getPassword().equals(pass))
                            System.out.println("登录成功");
                        else
                            System.out.println("密码不正确，登录失败");
                        break;
                    }
                }
        }
    }
    public static void showStudents(){
        System.out.println("学生姓名  所在班级  学号");
        for(int i=0; i<studentList.size(); i++){
            System.out.println(studentList.get(i).name+"  "+studentList.get(i).Class+"  "
                    +studentList.get(i).stu_id);
        }
    }

    public static void showTeachers(){
        System.out.println("教师姓名  职位  工号");
        for(int i=0; i<teacherList.size(); i++){
            System.out.println(teacherList.get(i).name+"  "+teacherList.get(i).level+"  "
                    +teacherList.get(i).work_id);
        }
    }

    public static void main(String[] args){
        Users u = new Users();
        Student stu = new Student("liu", "123456", 20183622, "计8");
        Teacher tea = new Teacher("飞飞女神", "123123", 20023123, "院士");
        u.studentList.add(stu);
        u.teacherList.add(tea);
        for(User i : u.studentList)
            i.show();
        for(User i : u.teacherList)
            i.show();

    }

}
